document.write('<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "947332";</script>');
document.write('<script type="text/javascript" src="http://cbjs.baidu.com/js/o.js"></script>');